@echo off
setlocal
cd /d "%~dp0"
echo Dang kiem tra cu phap, RAM, Disk, EDID va quet thuc te...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0tests\KIEM_TRA_WINDOWS.ps1" -LiveScan
if errorlevel 1 (
    echo.
    echo [FAIL] Co loi, vui long gui anh cua so nay.
) else (
    echo.
    echo [PASS] Tat ca bai kiem tra da chay thanh cong.
)
pause
endlocal
