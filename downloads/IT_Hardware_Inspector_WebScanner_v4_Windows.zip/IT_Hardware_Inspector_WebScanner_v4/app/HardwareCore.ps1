﻿# IT Hardware Inspector v2.1 - Windows 10 / 11, Windows PowerShell 5.1
# Local, read-only inventory collection. No remote access or external endpoints.

function Get-DisplayText {
    param($Value, [string]$Fallback = 'Không có dữ liệu')
    if ($null -eq $Value) { return $Fallback }
    $s = [string]$Value
    if ([string]::IsNullOrWhiteSpace($s)) { return $Fallback }
    return $s.Trim()
}

function Format-ByteSize {
    param($Bytes)
    if ($null -eq $Bytes -or [string]$Bytes -eq '') { return 'Không có dữ liệu' }
    try {
        $n = [double]$Bytes
        if ($n -lt 0) { return 'Không có dữ liệu' }
        if ($n -ge 1TB) { return ('{0:N2} TB' -f ($n / 1TB)) }
        if ($n -ge 1GB) { return ('{0:N2} GB' -f ($n / 1GB)) }
        if ($n -ge 1MB) { return ('{0:N1} MB' -f ($n / 1MB)) }
        return ('{0:N0} B' -f $n)
    } catch { return 'Không có dữ liệu' }
}

function Get-RamGeneration {
    param($SMBIOSMemoryType, $MemoryType)
    $codes = @{ 20 = 'DDR'; 21 = 'DDR2'; 22 = 'DDR2 FB-DIMM'; 24 = 'DDR3'; 26 = 'DDR4'; 27 = 'LPDDR'; 28 = 'LPDDR2'; 29 = 'LPDDR3'; 30 = 'LPDDR4'; 31 = 'LPDDR4X'; 34 = 'DDR5'; 35 = 'LPDDR5' }
    foreach ($raw in @($SMBIOSMemoryType, $MemoryType)) {
        try {
            $code = [int]$raw
            if ($codes.ContainsKey($code)) { return [string]$codes[$code] }
        } catch { }
    }
    return 'Không xác định'
}

function Get-DiskCategory {
    param($MediaType, $BusType)
    $media = (Get-DisplayText $MediaType '').ToUpperInvariant()
    $bus = (Get-DisplayText $BusType '').ToUpperInvariant()
    if ($bus -eq 'NVME') { return 'SSD NVMe' }
    if ($media -eq 'SSD' -or $media -eq '4') {
        if ($bus -eq 'SATA') { return 'SSD SATA' }
        if ($bus -eq 'USB') { return 'SSD USB' }
        return 'SSD (bus khác / chưa rõ)'
    }
    if ($media -eq 'HDD' -or $media -eq '3') {
        if ($bus -eq 'SATA') { return 'HDD SATA' }
        if ($bus -eq 'USB') { return 'HDD USB' }
        return 'HDD (bus khác / chưa rõ)'
    }
    if ($bus -eq 'VIRTUAL' -or $bus -eq 'FILE BACKED VIRTUAL') { return 'Ổ đĩa ảo / chưa rõ' }
    return 'Không xác định (không tự suy đoán)'
}

function Normalize-DiskSerial {
    param($Serial)
    if ($null -eq $Serial) { return '' }
    return (([string]$Serial) -replace '[\s\-]', '').Trim().ToUpperInvariant()
}

function Find-MatchingPhysicalDisk {
    param($Disk, [object[]]$PhysicalDisks)
    $list = @($PhysicalDisks | Where-Object { $null -ne $_ })
    if ($list.Count -eq 0) { return $null }

    # Match tolerance must stay Double; Int32 overload of Math.Max overflows at large disk sizes.
    # Never use DeviceId as an assumed match for Get-Disk.Number: providers may differ.
    $serial = Normalize-DiskSerial $Disk.SerialNumber
    if ($serial) {
        $matches = @($list | Where-Object { (Normalize-DiskSerial $_.SerialNumber) -eq $serial })
        if ($matches.Count -eq 1) { return $matches[0] }
    }

    $label = Get-DisplayText $Disk.FriendlyName ''
    if (-not $label -and $Disk.PSObject.Properties['Model']) { $label = Get-DisplayText $Disk.Model '' }
    $matches = @($list | Where-Object {
        $otherLabel = Get-DisplayText $_.FriendlyName ''
        $similar = $label -and $otherLabel -and $label.Trim() -eq $otherLabel.Trim()
        $similar -and ([math]::Abs(([double]$_.Size) - ([double]$Disk.Size)) -le [math]::Max([double]1GB, ([double]$Disk.Size * 0.02)))
    })
    if ($matches.Count -eq 1) { return $matches[0] }

    # Capacity-only fallback allowed solely when there is exactly one candidate.
    $matches = @($list | Where-Object {
        $size = [double]$Disk.Size
        $size -gt 0 -and ([math]::Abs(([double]$_.Size) - $size) -le [math]::Max([double]1GB, ($size * 0.02)))
    })
    if ($matches.Count -eq 1) { return $matches[0] }
    return $null
}

function Invoke-InventoryQuery {
    param([string]$Label, [scriptblock]$Action, [System.Collections.ArrayList]$Warnings)
    try {
        @(& $Action)
    } catch {
        [void]$Warnings.Add(("{0}: {1}" -f $Label, $_.Exception.Message))
        @()
    }
}

function Convert-EdidChars {
    param($Array)
    if ($null -eq $Array) { return '' }
    $chars = @($Array | Where-Object { $_ -gt 0 } | ForEach-Object { [char][int]$_ })
    return (-join $chars).Trim()
}

function Get-HardwareReport {
    $warnings = New-Object System.Collections.ArrayList
    $cs = @(Invoke-InventoryQuery 'Máy tính' { Get-CimInstance Win32_ComputerSystem -ErrorAction Stop } $warnings) | Select-Object -First 1
    $bios = @(Invoke-InventoryQuery 'BIOS' { Get-CimInstance Win32_BIOS -ErrorAction Stop } $warnings) | Select-Object -First 1
    $os = @(Invoke-InventoryQuery 'Windows' { Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } $warnings) | Select-Object -First 1
    $board = @(Invoke-InventoryQuery 'Mainboard' { Get-CimInstance Win32_BaseBoard -ErrorAction Stop } $warnings) | Select-Object -First 1
    $cpus = @(Invoke-InventoryQuery 'CPU' { Get-CimInstance Win32_Processor -ErrorAction Stop } $warnings)
    $sticks = @(Invoke-InventoryQuery 'RAM' { Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop } $warnings)
    $sysDisks = @(Invoke-InventoryQuery 'Storage Get-Disk' { Get-Disk -ErrorAction Stop } $warnings)
    $physicalDisks = @(Invoke-InventoryQuery 'Storage Get-PhysicalDisk' { Get-PhysicalDisk -ErrorAction Stop } $warnings)
    $cimDisks = @(Invoke-InventoryQuery 'Storage Win32_DiskDrive' { Get-CimInstance Win32_DiskDrive -ErrorAction Stop } $warnings)
    $volumes = @(Invoke-InventoryQuery 'Ổ đĩa logic' { Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop } $warnings)
    $gpus = @(Invoke-InventoryQuery 'Card đồ họa' { Get-CimInstance Win32_VideoController -ErrorAction Stop } $warnings)
    $monitorIds = @(Invoke-InventoryQuery 'Màn hình EDID' { Get-CimInstance -Namespace root/wmi -ClassName WmiMonitorID -ErrorAction Stop } $warnings)
    $nets = @(Invoke-InventoryQuery 'Card mạng IP-enabled' { Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' -ErrorAction Stop } $warnings)
    $allNics = @(Invoke-InventoryQuery 'Card mạng vật lý' { Get-CimInstance Win32_NetworkAdapter -Filter 'PhysicalAdapter=True' -ErrorAction Stop } $warnings)

    $screens = @()
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        $screens = @([System.Windows.Forms.Screen]::AllScreens | ForEach-Object {
            [pscustomobject]@{
                DeviceName = $_.DeviceName
                Width = $_.Bounds.Width
                Height = $_.Bounds.Height
                IsPrimary = [bool]$_.Primary
            }
        })
    } catch {
        [void]$warnings.Add(("Độ phân giải màn hình: {0}" -f $_.Exception.Message))
    }

    $diskRecords = @()
    if ($sysDisks.Count -gt 0) {
        $diskRecords = @($sysDisks | Sort-Object Number | ForEach-Object {
            $item = $_
            $physical = Find-MatchingPhysicalDisk -Disk $item -PhysicalDisks $physicalDisks
            $legacy = @($cimDisks | Where-Object { [int]$_.Index -eq [int]$item.Number } | Select-Object -First 1)
            $friendly = Get-DisplayText $item.FriendlyName ''
            if (-not $friendly -and $legacy.Count) { $friendly = Get-DisplayText $legacy[0].Model '' }
            $media = if ($null -ne $physical) { [string]$physical.MediaType } else { '' }
            $bus = [string]$item.BusType
            if (($bus -eq 'Unknown' -or $bus -eq 'Unspecified' -or [string]::IsNullOrWhiteSpace($bus)) -and $null -ne $physical) { $bus = [string]$physical.BusType }
            [pscustomobject]@{
                Number = $item.Number
                Model = $friendly
                SerialNumber = if ($item.SerialNumber) { $item.SerialNumber } elseif ($legacy.Count) { $legacy[0].SerialNumber } else { '' }
                SizeBytes = $item.Size
                MediaType = $media
                BusType = $bus
                Category = Get-DiskCategory -MediaType $media -BusType $bus
                HealthStatus = if ($null -ne $physical) { [string]$physical.HealthStatus } else { [string]$item.HealthStatus }
                IsBoot = [bool]$item.IsBoot
                IsSystem = [bool]$item.IsSystem
            }
        })
    } elseif ($cimDisks.Count -gt 0) {
        # If Storage module is unavailable, keep the capacity/model, and only classify when safe.
        $diskRecords = @($cimDisks | Sort-Object Index | ForEach-Object {
            $item = $_
            $match = Find-MatchingPhysicalDisk -Disk $item -PhysicalDisks $physicalDisks
            $media = if ($null -ne $match) { [string]$match.MediaType } else { '' }
            [pscustomobject]@{
                Number = $item.Index
                Model = $item.Model
                SerialNumber = $item.SerialNumber
                SizeBytes = $item.Size
                MediaType = $media
                BusType = if ($null -ne $match) { [string]$match.BusType } else { 'Không rõ' }
                Category = Get-DiskCategory -MediaType $media -BusType $(if ($null -ne $match) { [string]$match.BusType } else { '' })
                HealthStatus = 'Không có dữ liệu'
                IsBoot = $false
                IsSystem = $false
            }
        })
    }

    $activeMonitorIds = @($monitorIds | Where-Object { $_.Active })
    $monitorRecords = @($activeMonitorIds | ForEach-Object {
        [pscustomobject]@{
            Name = Convert-EdidChars $_.UserFriendlyName
            ManufacturerID = Convert-EdidChars $_.ManufacturerName
            SerialNumber = Convert-EdidChars $_.SerialNumberID
            InstanceName = $_.InstanceName
            Active = [bool]$_.Active
        }
    })

    [pscustomobject]([ordered]@{
        AppVersion = '4.0.0'
        ScanTime = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        Computer = [pscustomobject]@{
            Name = $env:COMPUTERNAME
            Manufacturer = $cs.Manufacturer
            Model = $cs.Model
            Domain = $cs.Domain
            BIOSSerial = $bios.SerialNumber
            TotalMemoryBytes = $cs.TotalPhysicalMemory
        }
        OperatingSystem = [pscustomobject]@{
            Caption = $os.Caption
            Version = $os.Version
            BuildNumber = $os.BuildNumber
            OSArchitecture = $os.OSArchitecture
        }
        BaseBoard = [pscustomobject]@{
            Manufacturer = $board.Manufacturer
            Product = $board.Product
            SerialNumber = $board.SerialNumber
        }
        CPU = @($cpus | ForEach-Object { [pscustomobject]@{
            Name = $_.Name
            Manufacturer = $_.Manufacturer
            Description = $_.Description
            Socket = $_.SocketDesignation
            ProcessorId = $_.ProcessorId
            ArchitectureCode = $_.Architecture
            AddressWidth = $_.AddressWidth
            DataWidth = $_.DataWidth
            Cores = $_.NumberOfCores
            EnabledCores = $_.NumberOfEnabledCore
            Threads = $_.NumberOfLogicalProcessors
            CurrentClockMHz = $_.CurrentClockSpeed
            MaxClockMHz = $_.MaxClockSpeed
            L2CacheKB = $_.L2CacheSize
            L3CacheKB = $_.L3CacheSize
            LoadPercentage = $_.LoadPercentage
            VirtualizationFirmwareEnabled = $_.VirtualizationFirmwareEnabled
            VMMonitorModeExtensions = $_.VMMonitorModeExtensions
            SecondLevelAddressTranslationExtensions = $_.SecondLevelAddressTranslationExtensions
        } })
        RAM = @($sticks | ForEach-Object { [pscustomobject]@{
            CapacityBytes = $_.Capacity
            Generation = Get-RamGeneration -SMBIOSMemoryType $_.SMBIOSMemoryType -MemoryType $_.MemoryType
            ConfiguredClockMHz = $_.ConfiguredClockSpeed
            RatedSpeed = $_.Speed
            Manufacturer = $_.Manufacturer
            PartNumber = $_.PartNumber
            DeviceLocator = $_.DeviceLocator
            SerialNumber = $_.SerialNumber
        } })
        Disks = @($diskRecords)
        Volumes = @($volumes | Sort-Object DeviceID | ForEach-Object { [pscustomobject]@{
            Drive = $_.DeviceID
            Label = $_.VolumeName
            SizeBytes = $_.Size
            FreeBytes = $_.FreeSpace
        } })
        GPU = @($gpus | ForEach-Object { [pscustomobject]@{
            Name = $_.Name
            DriverVersion = $_.DriverVersion
        } })
        Monitors = @($monitorRecords)
        Screens = @($screens)
        NetworkAdapters = @($allNics | ForEach-Object { [pscustomobject]@{
            Name = $_.Name
            MACAddress = $_.MACAddress
            NetEnabled = $_.NetEnabled
            NetConnectionStatus = $_.NetConnectionStatus
        } })
        Network = @($nets | ForEach-Object { [pscustomobject]@{
            Description = $_.Description
            MACAddress = $_.MACAddress
            IPAddresses = @($_.IPAddress)
            Gateways = @($_.DefaultIPGateway)
            DHCPEnabled = $_.DHCPEnabled
        } })
        Warnings = @($warnings.ToArray())
    })
}
