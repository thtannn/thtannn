﻿# IT Hardware Inspector - Local Web Scanner v4
# Localhost only; no external network connections, no remote code execution.
param([ValidateRange(1025,65535)][int]$Port = 8766, [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$webRoot = Join-Path $root 'web'
. (Join-Path $PSScriptRoot 'HardwareCore.ps1')

function Send-LocalResponse {
    param($Stream, [int]$Status, [string]$ContentType, [string]$Content)
    $reason = switch ($Status) { 200 {'OK'} 400 {'Bad Request'} 403 {'Forbidden'} 404 {'Not Found'} 405 {'Method Not Allowed'} 500 {'Internal Server Error'} default {'Error'} }
    $body = [System.Text.Encoding]::UTF8.GetBytes($Content)
    $header = "HTTP/1.1 $Status $reason`r`nContent-Type: $ContentType`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nX-Frame-Options: DENY`r`nReferrer-Policy: no-referrer`r`nContent-Security-Policy: default-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'`r`nConnection: close`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
    $Stream.Write($headerBytes, 0, $headerBytes.Length)
    $Stream.Write($body, 0, $body.Length)
    $Stream.Flush()
}
function Json-Error {
    param([string]$Message)
    return (ConvertTo-Json -InputObject @{ok=$false;error=$Message} -Compress)
}
$sessionKey = [guid]::NewGuid().ToString('N')
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)
try { $listener.Start(16) } catch {
    Write-Host "[ERROR] Khong mo duoc cong $Port. Co the cong da duoc su dung. $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
$base = "http://127.0.0.1:$Port"
Write-Host ''
Write-Host '====================================================' -ForegroundColor Cyan
Write-Host '   IT HARDWARE INSPECTOR - WEB SCANNER v4.0'
Write-Host '====================================================' -ForegroundColor Cyan
Write-Host "Website: $base"
Write-Host 'Chi quet MAY DANG MO WEBSITE tai may nay.' -ForegroundColor Yellow
Write-Host 'Du lieu KHONG gui len Internet. Nhan Ctrl+C de tat.' -ForegroundColor Green
Write-Host ''
if (-not $NoBrowser) {
    try { Start-Process $base | Out-Null } catch { Write-Host "Mo thu cong: $base" }
}
try {
    while ($true) {
        $client = $null
        $reader = $null
        try {
            $client = $listener.AcceptTcpClient()
            $client.ReceiveTimeout = 15000
            $client.SendTimeout = 180000
            $stream = $client.GetStream()
            $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 8192, $true)
            $firstLine = $reader.ReadLine()
            if ([string]::IsNullOrWhiteSpace($firstLine)) { continue }
            $request = $firstLine.Split(' ')
            if ($request.Count -lt 3 -or $firstLine.Length -gt 2048) { Send-LocalResponse $stream 400 'text/plain; charset=utf-8' 'Malformed HTTP request'; continue }
            $method = $request[0].ToUpperInvariant()
            $route = $request[1].Split('?')[0]
            $headers = @{}
            $tooMany = $true
            for ($j=0; $j -lt 64; $j++) {
                $line = $reader.ReadLine()
                if ($null -eq $line) { break }
                if ($line -eq '') { $tooMany = $false; break }
                if ($line.Length -gt 8192) { break }
                $pos = $line.IndexOf(':')
                if ($pos -gt 0) { $headers[$line.Substring(0,$pos).Trim().ToLowerInvariant()] = $line.Substring($pos+1).Trim() }
            }
            if ($tooMany) { Send-LocalResponse $stream 400 'text/plain; charset=utf-8' 'Invalid headers'; continue }
            $allowedHosts = @("127.0.0.1:$Port", "localhost:$Port")
            if (-not $headers.ContainsKey('host') -or $allowedHosts -cnotcontains $headers['host'].ToLowerInvariant()) {
                Send-LocalResponse $stream 403 'text/plain; charset=utf-8' 'Invalid host'; continue
            }
            if ($method -eq 'POST') {
                if ($route -ne '/api/scan') { Send-LocalResponse $stream 404 'application/json; charset=utf-8' (Json-Error 'Unknown endpoint'); continue }
                if ($headers.ContainsKey('origin')) {
                    if (@("http://127.0.0.1:$Port", "http://localhost:$Port") -cnotcontains $headers['origin'].ToLowerInvariant()) {
                        Send-LocalResponse $stream 403 'application/json; charset=utf-8' (Json-Error 'Cross-origin request denied'); continue
                    }
                }
                if (-not $headers.ContainsKey('x-scan-token') -or $headers['x-scan-token'] -cne $sessionKey) {
                    Send-LocalResponse $stream 403 'application/json; charset=utf-8' (Json-Error 'Invalid scan token'); continue
                }
                if ($headers.ContainsKey('transfer-encoding')) { Send-LocalResponse $stream 400 'application/json; charset=utf-8' (Json-Error 'Unsupported request encoding'); continue }
                if ($headers.ContainsKey('content-length') -and $headers['content-length'] -ne '0') { Send-LocalResponse $stream 400 'application/json; charset=utf-8' (Json-Error 'Request body not accepted'); continue }
                try {
                    Write-Host "[$(Get-Date -Format HH:mm:ss)] Bat dau quet cau hinh ..." -ForegroundColor Cyan
                    $report = Get-HardwareReport
                    $json = ConvertTo-Json -InputObject @{ok=$true; report=$report} -Depth 14 -Compress
                    Send-LocalResponse $stream 200 'application/json; charset=utf-8' $json
                    Write-Host "[$(Get-Date -Format HH:mm:ss)] Quet thanh cong: $($report.Computer.Name)" -ForegroundColor Green
                } catch {
                    Write-Host "[SCAN ERROR] $($_ | Out-String)" -ForegroundColor Red
                    Send-LocalResponse $stream 500 'application/json; charset=utf-8' (Json-Error $_.Exception.Message)
                }
                continue
            }
            if ($method -ne 'GET') { Send-LocalResponse $stream 405 'text/plain; charset=utf-8' 'Method not allowed'; continue }
            if ($route -eq '/api/ping') { Send-LocalResponse $stream 200 'application/json; charset=utf-8' '{"ok":true,"mode":"local-only"}'; continue }
            if ($route -eq '/' -or $route -eq '/index.html') {
                $html = [System.IO.File]::ReadAllText((Join-Path $webRoot 'index.html'), [System.Text.Encoding]::UTF8)
                $html = $html.Replace('__SCAN_TOKEN__', $sessionKey)
                Send-LocalResponse $stream 200 'text/html; charset=utf-8' $html; continue
            }
            $staticPaths = @{
                '/assets/styles.css' = @('styles.css','text/css; charset=utf-8')
                '/assets/app.js' = @('app.js','application/javascript; charset=utf-8')
                '/favicon.svg' = @('favicon.svg','image/svg+xml')
            }
            if ($staticPaths.ContainsKey($route)) {
                $entry = $staticPaths[$route]
                $content = [System.IO.File]::ReadAllText((Join-Path $webRoot $entry[0]), [System.Text.Encoding]::UTF8)
                Send-LocalResponse $stream 200 $entry[1] $content; continue
            }
            Send-LocalResponse $stream 404 'text/plain; charset=utf-8' 'Not found'
        } catch {
            Write-Host "[HTTP ERROR] $($_.Exception.Message)" -ForegroundColor DarkYellow
        } finally {
            if ($null -ne $reader) { $reader.Dispose() }
            if ($null -ne $client) { $client.Close() }
        }
    }
} finally { $listener.Stop() }
