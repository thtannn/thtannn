# IT Hardware Inspector — Web Scanner v4.0

> Đây là phiên bản WEB QUÉT TRỰC TIẾP CẤU HÌNH MÁY ĐANG SỬ DỤNG, **khác** Web Dashboard v3 quản lý nhiều máy.

## Cách mở website trên Windows 10/11

1. Giải nén toàn bộ ZIP, **không chạy trực tiếp file .cmd trong ZIP**.
2. Mở thư mục `IT_Hardware_Inspector_WebScanner_v4`.
3. Nhấp đúp `CHAY_WEBSITE.cmd` (không cần Python, Node.js, pip hay Internet).
4. Windows PowerShell sẽ khởi động web server và tự mở trình duyệt mặc định tại `http://127.0.0.1:8766`.
5. Website tự bắt đầu quét khi được mở. Có thể nhấn **Quét lại** bất cứ lúc nào, xem CPU, RAM, Ổ cứng, Màn hình & GPU, Hệ thống, Mạng.
6. Xuất **JSON** (chi tiết toàn bộ) hoặc **CSV** (một dòng tổng hợp, mở bằng Excel).
7. **GIỮ MỞ** cửa sổ PowerShell khi sử dụng trang web. Nhấn Ctrl+C hoặc đóng cửa sổ để tắt web server.

Dữ liệu thu thập chỉ trên máy Windows **đang chạy `CHAY_WEBSITE.cmd`**. Nếu mở website này trên máy tính khác, máy đó không tự được quét; website chỉ lắng nghe địa chỉ 127.0.0.1, không công khai trong LAN.

## Những thông số đọc từ Windows

- **CPU (chi tiết):** tên CPU, manufacturer, socket, cores, enabled cores, threads, xung hiện tại và tối đa (do WMI báo), cache L2/L3, processor ID, 32/64-bit, virtualization firmware/VM monitor/SLAT, mức tải CPU ở thời điểm quét.
- **RAM:** tổng dung lượng, số thanh, DDR3/DDR4/DDR5 nếu SMBIOS cung cấp, tốc độ cấu hình, hãng, part number, slot và serial.
- **Ổ cứng:** từng disk, dung lượng, model, số serial, Media Type, bus SATA/NVMe/USB, SSD/HDD khi xác định chắc chắn, dung lượng từng phân vùng.
- **Màn hình:** độ phân giải từng màn, tên/serial màn hình từ EDID khi có, GPU và driver.
- **Máy:** Hostname, manufacturer, model, serial BIOS, mainboard.
- **Hệ thống:** phiên bản Windows, build, architecture.
- **Mạng:** IP, MAC, gateway, DHCP, card mạng.

**Giới hạn kỹ thuật:** Trình duyệt web thuần túy (đặc biệt website host trên Internet) **không có quyền** đọc đầy đủ các thông số trên, nên bản v4 sử dụng một thành phần quét **PowerShell chạy cục bộ** và web server local. Không cài agent riêng, không cần Python, không thu thập dữ liệu từ máy bên ngoài. Nhiệt độ CPU, công suất thực, tần số boost realtime và một số chi tiết chưa được xác minh, **không** hiển thị thông số giả.

Nếu muốn **một tên miền web công khai** có nút quét chính máy của người truy cập, vẫn cần một Agent/ứng dụng chạy trên máy người đó (hoặc ứng dụng desktop đóng gói webview). Chỉ upload HTML/CSS/JS lên hosting **không thể** tự scan phần cứng; vì vậy không thể coi v4 là một trang web public thuần browser.

## Khắc phục lỗi

- **Lỗi `Python was not found`:** đây không phải bản v4. Hãy chạy `CHAY_WEBSITE.cmd` trong thư mục **WebScanner_v4**; không chạy v3.
- **Trình duyệt không tự mở:** thủ công nhập `http://127.0.0.1:8766`.
- **Không truy cập được trang:** giữ cửa sổ PowerShell chạy; kiểm tra port 8766 bằng `netstat -ano | findstr :8766`. Nếu cổng bị chiếm dụng, chạy lệnh `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\app\Server.ps1 -Port 8888` tại thư mục này rồi mở `http://127.0.0.1:8888`.
- **Quét không thành công:** đọc thông báo đỏ trong cửa sổ PowerShell. Thử CMD `powershell.exe -NoProfile -Command "Get-CimInstance Win32_Processor | Format-List *"`. Nếu máy có chính sách chặn PowerShell hoặc truy cập WMI, liên hệ quản trị viên. Không tắt antivirus / chính sách bảo mật chỉ để chạy ứng dụng.
- **Tên màn hình không hiện:** WmiMonitorID/EDID thường thiếu khi dùng RDP, dock hoặc driver màn hình. Ở một số môi trường WinForms Screen không xác định được số màn hình.
- **Loại ổ cứng hiển thị Không xác định:** một số thiết bị không báo MediaType; ứng dụng không đoán theo tên model.
- **Windows Defender cảnh báo file tải:** kiểm tra nội dung source `.ps1`/`.js` trong ZIP trước khi chạy, không vô hiệu hóa Defender. Dùng môi trường test được phê duyệt trước khi triển khai trong doanh nghiệp.
- **Tiếng Việt lỗi trong PowerShell:** file `.ps1` có UTF-8 BOM để Windows PowerShell 5.1 đọc được, nếu người dùng tự biên tập hãy lưu dưới dạng UTF-8 BOM.

## Bảo mật / deploy

- Web server dùng `TcpListener` giới hạn **127.0.0.1**, tránh mở trong LAN hoặc Internet.
- Mỗi lần khởi động tạo một session token ngẫu nhiên, gửi qua HTML, API `/api/scan` chỉ chấp nhận POST có header token và Origin/Host nội bộ. Không có CORS hay API thực thi tùy ý.
- Dữ liệu quét chỉ ở **bộ nhớ**, không tự động lưu/gửi; chỉ xuất file khi bạn nhấn CSV/JSON.
- `.cmd` chạy PowerShell với `-ExecutionPolicy Bypass` áp dụng ở tiến trình riêng để đọc script, không đổi policy toàn hệ thống. Môi trường doanh nghiệp có chính sách Group Policy vẫn có thể chặn việc chạy script.
- Để phục vụ máy khác qua Internet cần kiến trúc Agent có consent, xác thực, HTTPS và quản lý thông tin serial/IP thích hợp; không nên expose server localhost này lên Internet.

## Kiểm thử

Trên Windows: chạy **`KIEM_TRA_WINDOWS.cmd`** để kiểm tra cú pháp PowerShell, các test RAM/SSD/HDD/EDID và quét máy thực tế.

`python tests/test_frontend.py` chạy thử HTML/JS với API giả lập qua Chromium (bài test phát triển, **không cần Python trên máy người dùng**). `python tests/test_static.py` kiểm tra mã nguồn và file đóng gói. Môi trường xây dựng ở Linux không thể xác minh PowerShell/WMI/driver trên Windows thực tế; bắt buộc chạy kiểm thử thực tế trên một máy Windows trước khi sử dụng rộng rãi.
