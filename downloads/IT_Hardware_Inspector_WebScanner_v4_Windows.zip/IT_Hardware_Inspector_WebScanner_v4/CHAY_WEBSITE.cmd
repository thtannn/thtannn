@echo off
setlocal
cd /d "%~dp0"
where powershell.exe >nul 2>nul
if errorlevel 1 (
  echo [LOI] Khong tim thay Windows PowerShell 5.1.
  pause
  exit /b 1
)
echo ==================================================
echo   IT HARDWARE INSPECTOR - WEB SCANNER v4.0
echo ==================================================
echo Dang khoi dong website local ...
echo KHONG dong cua so nay khi dang su dung website.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\Server.ps1" -Port 8766
if errorlevel 1 (
  echo.
  echo [LOI] Server khong khoi dong. Doc thong bao phia tren.
  pause
)
endlocal
