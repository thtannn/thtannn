from pathlib import Path
import unittest
import codecs

ROOT=Path(__file__).resolve().parents[1]
class PackageTests(unittest.TestCase):
 def test_files(self):
  for f in ['CHAY_WEBSITE.cmd','CHAY_KHONG_MO_BROWSER.cmd','app/Server.ps1','app/HardwareCore.ps1','web/index.html','web/styles.css','web/app.js','web/favicon.svg','README.md']:
   self.assertTrue((ROOT/f).is_file(),f)
 def test_windows_powershell_encoding(self):
  for p in (ROOT/'app').glob('*.ps1'):
   self.assertTrue(p.read_bytes().startswith(codecs.BOM_UTF8),str(p))
 def test_local_server(self):
  s=(ROOT/'app/Server.ps1').read_text('utf-8-sig')
  for t in ['IPAddress]::Loopback','x-scan-token','sessionKey','/api/scan','127.0.0.1','Content-Security-Policy','-cnotcontains']:
   self.assertIn(t,s)
  for t in ['Invoke-WebRequest','Invoke-RestMethod','New-CimSession']:
   self.assertNotIn(t,s)
 def test_cpu_fields(self):
  s=(ROOT/'app/HardwareCore.ps1').read_text('utf-8-sig')
  for t in ['Cores = $_.NumberOfCores','Threads = $_.NumberOfLogicalProcessors','L2CacheKB = $_.L2CacheSize','L3CacheKB = $_.L3CacheSize','VirtualizationFirmwareEnabled','Get-PhysicalDisk','WmiMonitorID']:
   self.assertIn(t,s)
 def test_frontend_no_remote_resources(self):
  s=(ROOT/'web/index.html').read_text()
  self.assertIn('content="__SCAN_TOKEN__"',s)
  self.assertIn('/assets/app.js',s)
  self.assertNotIn('https://',s)
  js=(ROOT/'web/app.js').read_text()
  self.assertIn("fetch('/api/scan'",js)
  self.assertIn('csvSafe',js)
if __name__=='__main__': unittest.main(verbosity=2)
