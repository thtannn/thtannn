"""Local browser smoke test against mock hardware; does NOT exercise PowerShell on Windows."""
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import threading
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
OUT=Path('/mnt/data/IT_Hardware_Inspector_WebScanner_v4_preview.png')
DATA={
 'AppVersion':'4.0.0','ScanTime':'2026-10-26 11:15:05',
 'Computer':{'Name':'PC-IT-DEMO','Manufacturer':'Dell Inc.','Model':'OptiPlex 7090','Domain':'WORKGROUP','BIOSSerial':'DEMO-123456','TotalMemoryBytes':17179869184},
 'OperatingSystem':{'Caption':'Microsoft Windows 11 Pro','Version':'10.0.22631','BuildNumber':'22631','OSArchitecture':'64-bit'},
 'BaseBoard':{'Manufacturer':'Dell Inc.','Product':'0X001','SerialNumber':'MAIN-DEMO-123'},
 'CPU':[{'Name':'Intel(R) Core(TM) i5-11400 CPU @ 2.60GHz','Manufacturer':'GenuineIntel','Description':'Intel64 Family 6 Model 167 Stepping 1','Socket':'LGA1200','ProcessorId':'A1B2C3D4', 'ArchitectureCode':9,'AddressWidth':64,'DataWidth':64,'Cores':6,'EnabledCores':6,'Threads':12,'CurrentClockMHz':2592,'MaxClockMHz':4400,'L2CacheKB':1536,'L3CacheKB':12288,'LoadPercentage':13,'VirtualizationFirmwareEnabled':True,'VMMonitorModeExtensions':True,'SecondLevelAddressTranslationExtensions':True}],
 'RAM':[{'CapacityBytes':8589934592,'Generation':'DDR4','ConfiguredClockMHz':3200,'RatedSpeed':3200,'Manufacturer':'Kingston','PartNumber':'KVR32','DeviceLocator':'DIMM1','SerialNumber':'S123'},{'CapacityBytes':8589934592,'Generation':'DDR4','ConfiguredClockMHz':3200,'RatedSpeed':3200,'Manufacturer':'Kingston','PartNumber':'KVR32','DeviceLocator':'DIMM2','SerialNumber':'S124'}],
 'Disks':[{'Number':0,'Model':'Samsung 980 500GB','SizeBytes':500107862016,'Category':'SSD NVMe','BusType':'NVMe','MediaType':'SSD','HealthStatus':'Healthy','IsBoot':True,'IsSystem':True,'SerialNumber':'SIM-1'},{'Number':1,'Model':'Seagate 1TB','SizeBytes':1000204886016,'Category':'HDD SATA','BusType':'SATA','MediaType':'HDD','HealthStatus':'Healthy','IsBoot':False,'IsSystem':False,'SerialNumber':'SIM-2'}],
 'Volumes':[{'Drive':'C:','Label':'System','SizeBytes':500107862016,'FreeBytes':209715200000},{'Drive':'D:','Label':'Data','SizeBytes':1000204886016,'FreeBytes':536870912000}],
 'GPU':[{'Name':'Intel UHD Graphics 730','DriverVersion':'31.0.101.5500'}],
 'Screens':[{'DeviceName':r'\\.\DISPLAY1','Width':1920,'Height':1080,'IsPrimary':True}],
 'Monitors':[{'Name':'DELL P2419H','ManufacturerID':'DEL','SerialNumber':'SIM-MON-1','Active':True}],
 'Network':[{'Description':'Intel Ethernet Connection','MACAddress':'00:11:22:33:44:55','IPAddresses':['192.168.1.20'],'Gateways':['192.168.1.1'],'DHCPEnabled':True}],
 'NetworkAdapters':[{'Name':'Intel Ethernet','MACAddress':'00:11:22:33:44:55','NetEnabled':True,'NetConnectionStatus':2}],
 'Warnings':[]
}
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  path=self.path.split('?')[0]
  paths={'/':'index.html','/favicon.svg':'favicon.svg','/assets/styles.css':'styles.css','/assets/app.js':'app.js'}
  if path not in paths:self.send_error(404);return
  data=(ROOT/'web'/paths[path]).read_bytes()
  if path=='/':data=data.replace(b'__SCAN_TOKEN__',b'test-session-token')
  self.send_response(200)
  self.send_header('Content-Type', 'text/html; charset=utf-8' if path=='/' else 'text/css' if path.endswith('css') else 'application/javascript' if path.endswith('js') else 'image/svg+xml')
  self.send_header('Content-Length',str(len(data)))
  self.end_headers();self.wfile.write(data)
 def do_POST(self):
  if self.path!='/api/scan' or self.headers.get('X-Scan-Token')!='test-session-token':self.send_error(403);return
  payload=json.dumps({'ok':True,'report':DATA}).encode()
  self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload)
 def log_message(self,*args):pass

def test():
 errors=[]
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=browser.new_page(viewport={'width':1480,'height':940},device_scale_factor=1,accept_downloads=True)
  page.on('pageerror',lambda e:errors.append(str(e)))
  html=(ROOT/'web/index.html').read_text().replace('__SCAN_TOKEN__','test-session-token')
  page.set_content(html)
  page.add_style_tag(content=(ROOT/'web/styles.css').read_text())
  page.evaluate('''window.fetch = async (url, options) => ({
    ok: true, status: 200, json: async()=>({ok:true,report:window.__testReport})
  });''')
  page.evaluate('(r)=>window.__testReport=r', DATA)
  page.add_script_tag(content=(ROOT/'web/app.js').read_text())
  page.get_by_text('Quét hoàn tất',exact=False).wait_for(timeout=5000)
  assert page.get_by_text('PC-IT-DEMO').count()>=1
  assert page.get_by_text('Intel(R) Core(TM) i5-11400 CPU @ 2.60GHz').count()>=1
  page.screenshot(path=str(OUT),full_page=True)
  page.locator('[data-view="cpu"]').click()
  assert page.get_by_text('Cache L2').is_visible()
  assert page.get_by_text('Cache L3').is_visible()
  assert page.get_by_text('LGA1200').is_visible()
  page.screenshot(path='/mnt/data/IT_Hardware_Inspector_WebScanner_v4_CPU_preview.png',full_page=True)
  page.locator('[data-view="storage"]').click()
  assert page.get_by_text('Samsung 980 500GB',exact=True).is_visible()
  assert page.get_by_text('HDD SATA').first.is_visible()
  page.locator('[data-view="display"]').click()
  assert page.get_by_text('DELL P2419H').is_visible()
  page.locator('[data-view="ram"]').click()
  assert page.get_by_text('Kingston').count()==2
  page.locator('[data-view="network"]').click()
  assert page.get_by_text('192.168.1.20').is_visible()
  page.locator('[data-view="system"]').click()
  assert page.get_by_text('Windows 11 Pro').is_visible()
  page.locator('[data-view="overview"]').click()
  with page.expect_download() as download:
   page.locator('#exportJson').click()
  assert download.value.suggested_filename.startswith('hardware_PC-IT-DEMO')
  with page.expect_download() as download:
   page.locator('#exportCsv').click()
  assert download.value.suggested_filename.endswith('.csv')
  page.locator('#scanBtn').click()
  page.get_by_text('Quét hoàn tất',exact=False).wait_for(timeout=5000)
  assert not errors,errors
  print('PASS: auto scan, CPU details, RAM, storage, monitors, network, system, navigation, export CSV/JSON, rescan, JS errors=0')
  print('Screenshots:',OUT)
  browser.close()
if __name__=='__main__':test()
