﻿param([switch]$LiveScan)
$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $PSScriptRoot
$files = @(
    (Join-Path $base 'app\Server.ps1'),
    (Join-Path $base 'app\HardwareCore.ps1')
)
$passed = 0
$failed = 0
function Test-True {
    param([bool]$Condition, [string]$Description)
    if ($Condition) { $script:passed++; Write-Host "[PASS] $Description" -ForegroundColor Green }
    else { $script:failed++; Write-Host "[FAIL] $Description" -ForegroundColor Red }
}
Write-Host '==== WEB SCANNER v4 - WINDOWS SELF TEST ====' -ForegroundColor Cyan
foreach ($file in $files) {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($file, [ref]$tokens, [ref]$errors)
    Test-True ($errors.Count -eq 0) ("Cú pháp: {0}" -f (Split-Path $file -Leaf))
    if ($errors.Count) { $errors | ForEach-Object { Write-Host $_.ToString() -ForegroundColor Red } }
}
. (Join-Path $base 'app\HardwareCore.ps1')
Test-True ((Get-RamGeneration 26 0) -eq 'DDR4') 'SMBIOS DDR4'
Test-True ((Get-RamGeneration 34 0) -eq 'DDR5') 'SMBIOS DDR5'
Test-True ((Get-RamGeneration 0 24) -eq 'DDR3') 'RAM fallback'
Test-True ((Get-RamGeneration 0 0) -eq 'Không xác định') 'RAM unknown (không đoán)'
Test-True ((Get-DiskCategory -MediaType 'SSD' -BusType 'SATA') -eq 'SSD SATA') 'SSD SATA'
Test-True ((Get-DiskCategory -MediaType 'Unspecified' -BusType 'NVMe') -eq 'SSD NVMe') 'NVMe xác định được qua bus'
Test-True ((Get-DiskCategory -MediaType 'HDD' -BusType 'SATA') -eq 'HDD SATA') 'HDD SATA'
Test-True ((Get-DiskCategory -MediaType 'Unspecified' -BusType 'SATA') -match 'Không xác định') 'Không phân loại bừa ổ SATA'
Test-True ((Convert-EdidChars @(68,69,76,76,0,0)) -eq 'DELL') 'Giải mã tên EDID'

$mock = @(
    [pscustomobject]@{ FriendlyName='SATA SSD'; SerialNumber='SN-001'; Size=500GB; MediaType='SSD' },
    [pscustomobject]@{ FriendlyName='HDD'; SerialNumber='SN-002'; Size=1TB; MediaType='HDD' }
)
$match = Find-MatchingPhysicalDisk -Disk ([pscustomobject]@{FriendlyName='SATA SSD';SerialNumber='SN-001';Size=500GB}) -PhysicalDisks $mock
Test-True (($null -ne $match) -and ($match.MediaType -eq 'SSD')) 'Đối chiếu ổ cứng qua serial'
$ambiguous = @(
    [pscustomobject]@{ FriendlyName='Disk A'; SerialNumber=''; Size=500GB; MediaType='SSD' },
    [pscustomobject]@{ FriendlyName='Disk B'; SerialNumber=''; Size=500GB; MediaType='HDD' }
)
$notMatched = Find-MatchingPhysicalDisk -Disk ([pscustomobject]@{FriendlyName='Other';SerialNumber='';Size=500GB}) -PhysicalDisks $ambiguous
Test-True ($null -eq $notMatched) 'Ổ cùng dung lượng nhưng không khớp: không đoán'

# Regression for v2.0 crash: Math.Max(Int32, Double) could bind to Int32 and
# throw when 2% of a disk capacity exceeds 2,147,483,647 bytes.
# Exercise both the model-name path and the capacity-only fallback path.
$largeByName = @(
    [pscustomobject]@{ FriendlyName='Large NVMe'; SerialNumber=''; Size=501GB; MediaType='SSD' }
)
$largeNameMatch = Find-MatchingPhysicalDisk -Disk ([pscustomobject]@{ FriendlyName='Large NVMe'; SerialNumber=''; Size=500GB }) -PhysicalDisks $largeByName
Test-True (($null -ne $largeNameMatch) -and ($largeNameMatch.MediaType -eq 'SSD')) 'Regression 500GB: match qua ten khong loi Int32'

$largeBySize = @(
    [pscustomobject]@{ FriendlyName='Unknown vendor'; SerialNumber=''; Size=5TB; MediaType='HDD' }
)
$largeSizeMatch = Find-MatchingPhysicalDisk -Disk ([pscustomobject]@{ FriendlyName='Disk via Storage'; SerialNumber=''; Size=5TB }) -PhysicalDisks $largeBySize
Test-True (($null -ne $largeSizeMatch) -and ($largeSizeMatch.MediaType -eq 'HDD')) 'Regression 5TB: fallback dung luong khong loi Int32'

$largeMismatch = Find-MatchingPhysicalDisk -Disk ([pscustomobject]@{ FriendlyName='Different'; SerialNumber=''; Size=4TB }) -PhysicalDisks $largeBySize
Test-True ($null -eq $largeMismatch) 'Regression 4TB vs 5TB: khong match sai o cung'

if ($LiveScan) {
    Write-Host 'Đang chạy scan thật (có thể mất vài giây)...' -ForegroundColor Cyan
    try {
        $result = Get-HardwareReport
        Test-True (-not [string]::IsNullOrWhiteSpace([string]$result.Computer.Name)) 'Có tên máy tính'
        Test-True ($null -ne $result.Disks) 'Kết quả chứa danh sách ổ cứng'
        Test-True ($null -ne $result.Screens) 'Kết quả chứa màn hình'
        Test-True ($null -ne $result.Warnings) 'Kết quả chứa trạng thái truy vấn'
        Write-Host ("Máy: {0}; RAM: {1}; HDD/SSD: {2}; screens: {3}; warnings: {4}" -f $result.Computer.Name, (Format-ByteSize $result.Computer.TotalMemoryBytes), @($result.Disks).Count, @($result.Screens).Count, @($result.Warnings).Count)
    } catch {
        $script:failed++
        Write-Host ("[FAIL] Scan thật: {0}" -f $_.Exception.Message) -ForegroundColor Red
    }
}
Write-Host ''
Write-Host ("KẾT QUẢ: PASS={0}; FAIL={1}" -f $script:passed,$script:failed) -ForegroundColor Cyan
if ($failed -gt 0) { exit 1 }
exit 0
