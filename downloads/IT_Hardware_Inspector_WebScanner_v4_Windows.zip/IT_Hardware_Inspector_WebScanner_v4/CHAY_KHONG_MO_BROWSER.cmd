@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\Server.ps1" -Port 8766 -NoBrowser
if errorlevel 1 pause
endlocal
